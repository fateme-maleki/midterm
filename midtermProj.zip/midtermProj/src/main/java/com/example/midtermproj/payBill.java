package com.example.midtermproj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;

public class payBill extends  HelloApplication{
    @FXML
    TextField number;
    @FXML
    TextField type;
    @FXML
    Label payed;
    @FXML
    Button payButton;
    @FXML
    Button newButton;

    public void pay(ActionEvent clickevent) throws IOException {
        payed.setText("bill payed");
    }

    public  void newBill( ActionEvent clickevent) throws IOException{
        FXMLLoader fxml = new FXMLLoader(mainMenu.class.getResource("newBill.fxml"));
        Scene bill = new Scene(fxml.load(), 500, 400);
        stg.setScene(bill);
        stg.show();
    }
}
