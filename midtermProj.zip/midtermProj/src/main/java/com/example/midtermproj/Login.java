package com.example.midtermproj;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



import java.io.IOException;



public class Login extends HelloApplication {
    @FXML
    TextField  usernameInput;
    @FXML
    PasswordField passwordInput;
    @FXML
    Button submitButton;
    @FXML
    Label wrongUsername;
    @FXML
    Label wrongPassword;

    @FXML
    public void onSubmit(ActionEvent clickEvent) throws IOException {
        Boolean a = usernameInput.getText().equals("admin");
        Boolean b = passwordInput.getText().equals("1234");

       if (!a){

           wrongUsername.setText("username is wrong");
           usernameInput.clear();

       }
       if(!b){

            wrongPassword.setText("password is wrong");
           passwordInput.clear();
        }


        if(a&&b) {
           FXMLLoader fxml = new FXMLLoader(mainMenu.class.getResource("mainMenu.fxml"));
           Scene firstMenu = new Scene(fxml.load(), 500, 400);

            stg.setScene(firstMenu);
            stg.show();
       }
    }


}
