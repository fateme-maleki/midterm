package com.example.midtermproj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;

public class createAcount  extends  HelloApplication{
    @FXML
    TextField firstName;
    @FXML
    TextField sureName;
    @FXML
    TextField accountBalance;
    @FXML
    TextField password;
    @FXML
    TextField bankName;
    @FXML
    Button submitButton;
    @FXML
    Label noMessage;
    @FXML
    Label yesMessage;

public void submitInformation(ActionEvent clickevent) throws IOException{
  createFile();

    insertToFile(firstName.getText());
    insertToFile(sureName.getText());
    insertToFile(accountBalance.getText());
    insertToFile(password.getText());
    insertToFile(bankName.getText()) ;


}

 public void  createFile() throws IOException {
     File account = new File("account.txt");
     if (account.createNewFile()) {
         yesMessage.setText("Account created");
     } else {
         noMessage.setText("Account already exists");
     }

 }

public void insertToFile(String data) throws  IOException{ String[] information = new String[5];

    FileWriter accountWriter = new FileWriter("account.txt");
    accountWriter.write(data);
    
}




}








