package com.example.midtermproj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;

public class withdrawal {
    @FXML
    TextField amount;
    @FXML
    Button click;
    @FXML
    Label remaining;
    @FXML
    Label money;
    @FXML
    Label notenough;

    public  void  onClick(ActionEvent clickevent) throws IOException{
       int c= 2000 - amount.getLength();
         if(c>0){
             remaining.setText("Your remaining balance :");
             String b=Integer.toString(c);
             money.setText(b);
         }else{
             notenough.setText("You can't withdraw");
         }

    }
}
