package com.example.midtermproj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

import java.io.IOException;

public class mainMenu extends HelloApplication{

    @FXML
    Button mainButton;
    @FXML
    Button aButton;
    @FXML
    Button bButton;
   
    @FXML
    Label chooseLabel;
    @FXML
    ImageView image;

    public void tomainBank(ActionEvent clickevent) throws IOException{
        FXMLLoader fxml = new FXMLLoader(mainMenu.class.getResource("mainBank.fxml"));
        Scene mainBank = new Scene(fxml.load(), 500, 400);

        stg.setScene(mainBank);
        stg.show();
    }
    public void toBanka(ActionEvent clickevent) throws IOException{
        FXMLLoader fxml = new FXMLLoader(mainMenu.class.getResource("banka.fxml"));
        Scene banka = new Scene(fxml.load(), 500, 400);

        stg.setScene(banka);
        stg.show();
    }
    public void toBankb(ActionEvent clickevent) throws IOException{
        FXMLLoader fxml = new FXMLLoader(mainMenu.class.getResource("bankb.fxml"));
        Scene bankb = new Scene(fxml.load(), 500, 400);

        stg.setScene(bankb);
        stg.show();
    }


}
