package com.example.midtermproj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.io.IOException;

public class mainBank extends HelloApplication {
    @FXML
    Label mainbankLabel;
    @FXML
    Button accountButton;
    @FXML
    Button withdrawalButton;
    @FXML
    Button billButton;
    @FXML
    Button transferButton;
    @FXML
    Button reportButton;

    public void createAccount(ActionEvent clickevent) throws IOException {
        FXMLLoader fxml = new FXMLLoader(mainMenu.class.getResource("createAcount.fxml"));
        Scene createAcount = new Scene(fxml.load(), 500, 400);

        stg.setScene(createAcount);
        stg.show();
    }

    public void withdraw(ActionEvent clickevent) throws IOException{
        FXMLLoader fxml = new FXMLLoader(mainMenu.class.getResource("withdrawal.fxml"));
        Scene with = new Scene(fxml.load(), 500, 400);
        stg.setScene(with);
        stg.show();
    }

    public void payBill(ActionEvent clickevent) throws IOException{
        FXMLLoader fxml = new FXMLLoader(mainMenu.class.getResource("payBill.fxml"));
        Scene pay = new Scene(fxml.load(), 500, 400);
        stg.setScene(pay);
        stg.show();
    }

    public void transfer(ActionEvent clickevent) throws IOException{
        FXMLLoader fxml = new FXMLLoader(mainMenu.class.getResource("transfer.fxml"));
        Scene trans = new Scene(fxml.load(), 500, 400);
        stg.setScene(trans);
        stg.show();
    }

    public void accountReport(ActionEvent clickevent) throws IOException{

    }


}
