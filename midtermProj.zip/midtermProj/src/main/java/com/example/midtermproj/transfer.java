package com.example.midtermproj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.io.IOException;

public class transfer {
    @FXML
    Label message;
    public void show(ActionEvent clickevent) throws IOException {
        message.setText("transfer successful");

    }
}
