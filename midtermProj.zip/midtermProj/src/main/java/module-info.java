module com.example.midtermproj {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.midtermproj to javafx.fxml;
    exports com.example.midtermproj;
}